using SOLID.ISP.Solucao.Interfaces;

namespace SOLID.ISP.Solucao
{
    public class CadastroProduto : ICadastroProduto
    {
        public void ValidarDados()
        {
            // Validar valor
        }

        public void SalvarBanco()
        {
            // Insert tabela Produto
        }
    }
}