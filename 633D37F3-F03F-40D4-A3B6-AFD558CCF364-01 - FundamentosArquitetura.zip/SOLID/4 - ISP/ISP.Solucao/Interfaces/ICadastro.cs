﻿namespace SOLID.ISP.Solucao.Interfaces
{
    public interface ICadastro
    {
        void SalvarBanco();
    }
}