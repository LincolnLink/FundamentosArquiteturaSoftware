﻿namespace DesignPatterns
{
    public interface IPagamentoBoletoFacade
    {
        string GerarBoleto();
    }
}